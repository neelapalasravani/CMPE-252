import math

# Function to parse the input file
def parse_input(file_name):
    with open(file_name, 'r') as file:
        lines = file.readlines()
        n = int(lines[0].strip())
        start = int(lines[1].strip()) - 1  
        goal = int(lines[2].strip()) - 1   
        edges = {}
        
        for line in lines[3:]:
            i, j, wij = line.strip().split()
            i, j, wij = int(i) - 1, int(j) - 1, float(wij)  # Adjust index
            edges[(i, j)] = wij
            
    return n, start, goal, edges

# Bellman-Ford algorithm to find the shortest path
def bellman_ford(n, start, goal, edges):
    # Initialize distances and predecessors
    distance = [float('inf')] * n
    predecessor = [-1] * n
    distance[start] = 0

    # Relax edges up to n-1 times
    for _ in range(n - 1):
        for (u, v), w in edges.items():
            if distance[u] != float('inf') and distance[u] + w < distance[v]:
                distance[v] = distance[u] + w
                predecessor[v] = u

    # Check for negative-weight cycles
    for (u, v), w in edges.items():
        if distance[u] != float('inf') and distance[u] + w < distance[v]:
            raise ValueError("Graph contains a negative weight cycle")

    # Reconstruct the path from start to goal
    path = []
    current = goal

    while current != -1:
        path.append(current + 1)  # Convert back to 1-based indexing
        current = predecessor[current]

    path.reverse()  # Reverse to get path from start to goal

    return path, distance

# Main function
def main():
    input_file = 'input.txt'  
    output_file = '016801486.txt'  

    print("Parsing input files...")
    n, start, goal, edges = parse_input(input_file)

    print("Running Bellman-Ford algorithm...")
    # Run the Bellman-Ford algorithm
    try:
        path, distance = bellman_ford(n, start, goal, edges)
        print("Bellman-Ford completed successfully.")
    except ValueError as e:
        print(e)
        return

    # Prepare output strings
    output_lines = []

    # Append the specific path to the goal in the desired format first
    if path:
        output_lines.append(f"Shortest path: {' '.join(map(str, path))}\n")

    # Append the Optimal Value Function (Distances from Start)
    output_lines.append("Optimal Value Function:\n")
    output_lines.append(" ".join(f"{dist:.6f}" for dist in distance) + "\n")

    print("Writing output to file...")
    # Write to the output file
    try:
        with open(output_file, 'w') as file:
            file.writelines(output_lines)
        print(f"Output successfully written to {output_file}.")
    except Exception as e:
        print(f"Failed to write to file: {e}")

# Execute the main function
main()
