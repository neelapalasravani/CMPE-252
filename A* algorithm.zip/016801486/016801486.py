import sys
from heapq import heappop, heappush
import math
import matplotlib.pyplot as plt
import os
from moviepy.editor import ImageSequenceClip, clips_array
import re

# Data parsing of input file
def parse_input_file(input_file):
    with open(input_file, 'r') as f:
        lines = f.readlines()

    num_vertices = int(lines[0].strip())  # Number of vertices
    start = int(lines[1].strip())  # Start node
    end = int(lines[2].strip())  # End node

    graph = {i: {} for i in range(1, num_vertices + 1)} 

    for line in lines[3:]:
        v1, v2, w = line.strip().split()
        v1, v2, w = int(v1), int(v2), float(w)
        graph[v1][v2] = w

    return graph, start, end

# Data parsing of coordinates file
def parse_coords_file(coords_file):
    with open(coords_file, 'r') as f:
        coords = [tuple(map(float, line.strip().split())) for line in f.readlines()]
    return {i + 1: coord for i, coord in enumerate(coords)}

# Euclidean heuristic
def euclidean_heuristic(coord1, coord2):
    return math.sqrt((coord1[0] - coord2[0])**2 + (coord1[1] - coord2[1])**2)

# Function to run a general A* algorithm with custom ε
def astar_algo(graph, src, dest, coordinates, epsilon=1, algorithm_name="A_star"):
    open_set = []
    heappush(open_set, (0, src))
    came_from = {}
    g_score = {node: float('inf') for node in graph}
    g_score[src] = 0
    f_score = {node: float('inf') for node in graph}
    f_score[src] = euclidean_heuristic(coordinates[src], coordinates[dest]) * epsilon

    frame_number = 0
    visited = set()

    sanitized_algorithm_name = sanitize_name(algorithm_name)
    algo_dir = f'frames/{sanitized_algorithm_name}'
    if not os.path.exists(algo_dir):
        os.makedirs(algo_dir)

    while open_set:
        current = heappop(open_set)[1]
        visited.add(current)

        # Save frame at each step
        plot_shortest_path_graph(graph, coordinates, None, frame_number, visited, came_from, sanitized_algorithm_name, algo_dir)
        frame_number += 1

        if current == dest:
            path = []
            edges = []
            while current in came_from:
                path.append(current)
                current, edge_cost = came_from[current]
                edges.append(edge_cost)
            path.append(src)
            path.reverse()
            edges.reverse()
            return f_score[dest], path, edges, frame_number

        for neighbor, weight in graph[current].items():
            tentative_g_score = g_score[current] + weight
            if tentative_g_score < g_score[neighbor]:
                came_from[neighbor] = (current, weight)
                g_score[neighbor] = tentative_g_score
                f_score[neighbor] = tentative_g_score + euclidean_heuristic(coordinates[neighbor], coordinates[dest]) * epsilon
                heappush(open_set, (f_score[neighbor], neighbor))

    return float('inf'), [], [], frame_number

# Dijkstra Algorithm (equivalent to A* with epsilon = 0)
def dijkstra_algo(graph, src, dest, coordinates):
    return astar_algo(graph, src, dest, coordinates, epsilon=0, algorithm_name="Dijkstra")

# Plot graph with shortest path
def plot_shortest_path_graph(graph, coordinates, shortest_path, step, visited, node_data, algorithm_name, algo_dir):
    plt.figure(figsize=(6, 5))
    
    # Plot nodes
    for node, coord in coordinates.items():
        plt.scatter(coord[0], coord[1], color='gray')
        plt.text(coord[0], coord[1], f'{node}', fontsize=12, ha='left')
    
    # Plot edges
    for v1 in graph:
        for v2 in graph[v1]:
            x_values = [coordinates[v1][0], coordinates[v2][0]]
            y_values = [coordinates[v1][1], coordinates[v2][1]]
            plt.plot(x_values, y_values, 'blue')

    # Highlight visited nodes and edges
    for node in visited:
        for neighbor in graph[node]:
            if neighbor in visited:
                x_values = [coordinates[node][0], coordinates[neighbor][0]]
                y_values = [coordinates[node][1], coordinates[neighbor][1]]
                plt.plot(x_values, y_values, 'green', linestyle='dashed')

    # Highlight the shortest path
    if shortest_path:
        for i in range(len(shortest_path) - 1):
            v1, v2 = shortest_path[i], shortest_path[i + 1]
            x_values = [coordinates[v1][0], coordinates[v2][0]]
            y_values = [coordinates[v1][1], coordinates[v2][1]]
            plt.plot(x_values, y_values, 'red', linewidth=2)
    
    plt.title(f"{algorithm_name} - Step {step}")
    plt.grid(True)
    frame_path = f"{algo_dir}/{algorithm_name}_frame_{step}.png"
    plt.savefig(frame_path)
    plt.close()
    print(f"Saved frame: {frame_path}")

# Function to print the shortest path and travel costs in required format
def print_shortest_path_and_cost(path, edges):
    # Print vertices in the path
    print(' '.join(map(str, path)))

    # Calculate and print cumulative travel costs
    cumulative_cost = 0
    costs = []
    for edge_cost in edges:
        cumulative_cost += edge_cost
        costs.append(f'{cumulative_cost:.4f}')
    print(' '.join(costs))

# Sanitize name to remove special characters
def sanitize_name(name):
    return re.sub(r'[^a-zA-Z0-9]', '_', name)

# 6 algorithm results
def run_algorithms(graph, source, destination, coordinates):
    if not os.path.exists('frames'):
        os.makedirs('frames')

    algorithms = [
        ("Dijkstra", dijkstra_algo, 0),
        ("A_star_epsilon_1", astar_algo, 1),
        ("Weighted_A_star_epsilon_2", astar_algo, 2),
        ("Weighted_A_star_epsilon_3", astar_algo, 3),
        ("Weighted_A_star_epsilon_4", astar_algo, 4),
        ("Weighted_A_star_epsilon_5", astar_algo, 5)
    ]

    with open('016801486.txt', 'w') as output_file:
        for title, algo, epsilon in algorithms:
            sanitized_title = sanitize_name(title)
            algo_dir = f'frames/{sanitized_title}'
            if not os.path.exists(algo_dir):
                os.makedirs(algo_dir)
            
            if algo == dijkstra_algo:
                dist, path, edges, steps = algo(graph, source, destination, coordinates)
            else:
                dist, path, edges, steps = algo(graph, source, destination, coordinates, epsilon=epsilon, algorithm_name=sanitized_title)
            
            # Plot the final path
            plot_shortest_path_graph(graph, coordinates, path, steps, set(graph.keys()), None, sanitized_title, algo_dir)
            
            # cumulative travelling costs
            cumulative_costs = []
            cumulative_cost = 0
            for edge_cost in edges:
                cumulative_cost += edge_cost
                cumulative_costs.append(f'{cumulative_cost:.4f}')
            
            # Results of output file
            output_file.write(f"{title}:\n")
            output_file.write(f"Shortest Distance: {dist}\n")
            output_file.write(f"Shortest Path: {' '.join(map(str, path))}\n")
            output_file.write(f"Travel Costs: {' '.join(cumulative_costs)}\n\n")

def create_video():
    algorithms = [
        "Dijkstra",
        "A_star_epsilon_1",
        "Weighted_A_star_epsilon_2",
        "Weighted_A_star_epsilon_3",
        "Weighted_A_star_epsilon_4",
        "Weighted_A_star_epsilon_5"
    ]

    clips = []
    max_frames = 0

    # Collect frames 
    algo_frames = {}
    for algo in algorithms:
        algo_dir = f'frames/{algo}'
        if not os.path.exists(algo_dir):
            print(f"Directory {algo_dir} does not exist.")
            continue
        frames = sorted([f"{algo_dir}/{frame}" for frame in os.listdir(algo_dir) if frame.startswith(algo)], key=lambda x: int(x.split('_')[-1].split('.')[0]))
        print(f"Frames for {algo}: {frames}")
        if frames:
            algo_frames[algo] = frames
            max_frames = max(max_frames, len(frames))

    # Extend frames 
    for algo, frames in algo_frames.items():
        last_frame = frames[-1]
        while len(frames) < max_frames:
            frames.append(last_frame)
        clip = ImageSequenceClip(frames, fps=1)
        clips.append(clip)

    if len(clips) == 6:
        final_clip = clips_array([[clips[0], clips[1], clips[2]], [clips[3], clips[4], clips[5]]])
        final_clip.write_videofile("016801486.mp4", fps=1)
    else:
        print("Not all algorithm frames were generated.")

#Required files
input_file = 'input.txt' 
coords_file = 'coords.txt'  

# Parse input and coordinates files
graph, source, destination = parse_input_file(input_file)
coordinates = parse_coords_file(coords_file)

# Running the 6 algorithms and generating frames
run_algorithms(graph, source, destination, coordinates)

# final video
create_video()