# Import necessary libraries
import sys
from heapq import heappush, heappop
import matplotlib.pyplot as plt  
import imageio.v2 as imageio  
import os

# Data parsing of input file
def parse_input_file(input_file):
    with open(input_file, 'r') as f:
        lines = f.readlines()

    num_vertices = int(lines[0].strip())  # Number of vertices
    start = int(lines[1].strip())  # Start node
    end = int(lines[2].strip())  # End node

    # Dictionary of the graph
    graph = {i: {} for i in range(1, num_vertices + 1)}

    # Connections start from line 3
    for line in lines[3:]:
        v1, v2, w = line.strip().split()
        v1, v2, w = int(v1), int(v2), float(w)
        graph[v1][v2] = w  # Directed graph

    return graph, start, end

# Data parsing of coordinates file
def parse_coords_file(coords_file):
    with open(coords_file, 'r') as f:
        coords = [tuple(map(float, line.strip().split())) for line in f.readlines()]
    return {i + 1: coord for i, coord in enumerate(coords)}

# Plot the graph
def plot_shortest_path_graph(graph, coordinates, shortest_path, step, visited, node_data):
    plt.figure(figsize=(5, 4))

    # Plot nodes
    for node, coord in coordinates.items():
        plt.scatter(coord[0], coord[1], color='gray')
        plt.text(coord[0], coord[1], f'{node}', fontsize=12, ha='left')

    # Plot edges
    for v1 in graph:
        for v2 in graph[v1]:
            x_values = [coordinates[v1][0], coordinates[v2][0]]
            y_values = [coordinates[v1][1], coordinates[v2][1]]
            plt.plot(x_values, y_values, 'blue')

    # Highlight visited nodes and edges
    for node in visited:
        for neighbor in graph[node]:
            if neighbor in visited:
                x_values = [coordinates[node][0], coordinates[neighbor][0]]
                y_values = [coordinates[node][1], coordinates[neighbor][1]]
                plt.plot(x_values, y_values, 'green', linestyle='dashed')

    # Highlight the shortest path
    if shortest_path:
        for i in range(len(shortest_path) - 1):
            v1, v2 = shortest_path[i], shortest_path[i + 1]
            x_values = [coordinates[v1][0], coordinates[v2][0]]
            y_values = [coordinates[v1][1], coordinates[v2][1]]
            plt.plot(x_values, y_values, 'red', linewidth=2)

    plt.title(f"Shortest_Path {step}")
    plt.grid(True)
    plt.savefig(f"step_{step}.png")
    plt.close()

# Implementation of Dijkstra's algorithm
def dijkstra_algo(graph, src, dest, coordinates):
    inf = sys.maxsize
    num_vertices = len(graph)

    node_data = {i: {'cost': inf, 'pred': [], 'edges': []} for i in range(1, num_vertices + 1)}
    node_data[src]['cost'] = 0  # Starting point

    visited = set()
    min_heap = [(0, src)]
    step = 0

    while min_heap:
        current_cost, temp = heappop(min_heap)
        if temp == dest:
            break
        if temp not in visited:
            visited.add(temp)
            for j in graph[temp]:
                if j not in visited:
                    cost = current_cost + graph[temp][j]
                    if cost < node_data[j]['cost']:
                        node_data[j]['cost'] = cost
                        node_data[j]['pred'] = node_data[temp]['pred'] + [temp]
                        node_data[j]['edges'] = node_data[temp]['edges'] + [graph[temp][j]]
                        heappush(min_heap, (cost, j))

            step += 1
            plot_shortest_path_graph(graph, coordinates, None, step, visited, node_data)

    if node_data[dest]['cost'] == inf:
        return None, None, None, step
    else:
        return node_data[dest]['cost'], node_data[dest]['pred'] + [dest], node_data[dest]['edges'], step

# Function to create a video
def create_shortest_path_video(steps):
    img = []
    for step in range(1, steps + 1):
        img.append(imageio.imread(f"step_{step}.png"))
    imageio.mimsave('016801486.mp4', img, fps=1)

# Output to a text file
def output_file(filename, shortest_distance, shortest_path, edges):
    with open(filename, 'w') as f:
        f.write(f"Shortest Distance: {shortest_distance}\n")
        f.write(f"Shortest Path: {'  '.join(map(str, shortest_path))}\n")

        # Calculate and write cumulative traveling costs
        cumulative_costs = []
        cumulative_sum = 0
        for edge_cost in edges:
            cumulative_sum += edge_cost
            cumulative_costs.append(cumulative_sum)

        # Write cumulative costs to the file
        f.write(f"Travelling Cost: {'  '.join(map(str, cumulative_costs))}\n")

# Provided the file paths from the directory
input_file = 'input.txt'
coords_file = 'coords.txt'

# Data parsing input and coordinates file
graph, source, destination = parse_input_file(input_file)
coordinates = parse_coords_file(coords_file)

# Display the output using Dijkstra's algorithm
shortest_distance, shortest_path, edges, step = dijkstra_algo(graph, source, destination, coordinates)

if shortest_path:
    print("Shortest Distance:", shortest_distance)
    print("Shortest Path:", '  '.join(map(str, shortest_path)))
    
    # cumulative costs
    cumulative_costs = [sum(edges[:i + 1]) for i in range(len(edges))]
    print("Travelling Cost:", '  '.join(map(str, cumulative_costs)))

    # Save output to a text file
    output_file('016801486.txt', shortest_distance, shortest_path, edges)

    # Plot the final shortest path graph
    plot_shortest_path_graph(graph, coordinates, shortest_path, step + 1, set(graph.keys()), None)
else:
    print("No path found.")
    output_file('016801486.txt', "No path found", [], [])

create_shortest_path_video(step + 1)

# Clean the generated images
# for step in range(1, step + 2):
#     os.remove(f"step_{step}.png")
